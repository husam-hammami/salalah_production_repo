const blueprint_url_prefix = 'orders';

const endpoints = {
  auth: {
    login: '/login',
    logout: '/logout',
    checkAuth:'/check-auth'
  },
  users: {
    list: '/users',
    create: '/add-user',
    delete: id => `/delete-user/${id}`,
    // details: id => `/user/${id}`,
    // update: '/update-user',
  },
  materials: {
    list: '/materials',
    create: '/add-material',
    details: id => `/material/${id}`,
    update: '/update-material',
    delete: id => `/delete-material/${id}`,
  },
  bins: {
    list: '/bins',
    assign: '/assign-bin',
    // details: (id) => `/bin/${id}`,
    // update: (id) => `/bin/${id}`,
    unassign: id => `/unassign-bin/${id}`,
  },
  jobTypes: {
    list: '/job-types',
    create: '/add-job-type',
    // details: (id) => `/job-type/${id}`,
    // update: (id) => `/job-type/${id}`,
    // delete: (id) => `/job-type/${id}`,
  },
  kpis: {
    list: id => `/kpis/${id}`,
    create: '/add-kpi-definition',
    delete: id => `/delete-kpi/${id}`,
    details: id => `/get-kpi/${id}`,
    update: '/update-kpi',
  },
  recipes: {
    list: id => `/job-fields/${id}`,
    create: '/add-recipe',
    details: id => `/load-recipe/${id}`,
    update: `/update-recipe`,
    delete: id => `/delete-recipe/${id}`,
  },
  orders: {
    list: `/${blueprint_url_prefix}/get-orders`,
    details: id =>
      `/${blueprint_url_prefix}/get-active-order?job_type_id=${id}`,
    release: id => `/${blueprint_url_prefix}/release-order/${id}`,
    duplicate: id => `/${blueprint_url_prefix}/duplicate-order/${id}`,
    delete: id => `/${blueprint_url_prefix}/delete-order/${id}`,
    submit: `/${blueprint_url_prefix}/submit-order`,
  },
  controlPanel: {
    send: `/${blueprint_url_prefix}/send-command`,
  },
};

export default endpoints;
