// Main imports
import './App.css';
import AppRouter from './Routes/AppRouter.jsx';

// Third parties imports
import { ToastContainer } from 'react-toastify';
import SplashScreen from './Components/Common/SplashScreen.jsx';
import useLoading from './Hooks/useLoading.jsx';
import { useContext } from 'react';
import { DarkModeContext } from './Context/DarkModeProvider.jsx';
import { AuthContext } from './Context/AuthProvider.jsx';

function App() {
  const loading = useLoading();
  const { mode } = useContext(DarkModeContext);
  return (
    <>
      {loading ? (
        <SplashScreen />
      ) : (
        <>
          <div className="app">
            <AppRouter />
            <ToastContainer
              position="top-right"
              autoClose={5000}
              closeOnClick
              rtl={false}
              pauseOnFocusLoss
              draggable
              pauseOnHover
              stacked
              theme={`${mode === 'dark' ? 'dark' : 'light'}`}
            />
          </div>
        </>
      )}
    </>
  );
}

export default App;
