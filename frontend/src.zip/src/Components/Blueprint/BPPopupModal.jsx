import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Checkbox,
} from '@mui/material';
import InputField from '../Common/InputField';
import SelectField from '../Common/SelectField';
import { useFormik } from 'formik';
import { toast } from 'react-toastify';
import * as Yup from 'yup';
import { useContext, useEffect, useMemo, useState } from 'react';
import { FlexContainer, FlexItem } from './FlexContainer';
import { JobTypesContext } from '../../Context/ApiContext/JobTypesContext';
import { BinsContext } from '../../Context/ApiContext/BinsContext';
import { OrdersContext } from '../../Context/ApiContext/OrdersContext';
import endpoints from '../../API/endpoints';
import axios from '../../API/axios';
import LoadingScreen from '../Common/LoadingScreen';
import ErrorScreen from '../Common/ErrorScreen';

const BPPopupModal = ({ open, onClose }) => {
  const { jobTypes } = useContext(JobTypesContext);
  const { bins } = useContext(BinsContext);
  const { refreshOrders, setOrdersLoading } = useContext(OrdersContext);

  const binsByMaterialId = useMemo(() => {
    return bins.reduce((acc, bin) => {
      if (!acc[bin.material_id]) {
        acc[bin.material_id] = []; // Initialize array if not already present
      }
      acc[bin.material_id].push({
        label: bin.bin_name, // Map bin_name to label
        value: bin.id, // Map id to id
      });
      return acc;
    }, {}); // Initialize as an empty object
  }, [bins]);

  const formik = useFormik({
    initialValues: {
      sources: [],
      destinations: [],
      kpis: [],
      job_type_id: jobTypes[0].id,
      recipe_id: '-1',
      stop_options:{}
    },
    validationSchema: Yup.object({
      // recipe_id: Yup.string().required('recipe_id Name is required'),
      // jobTypeSelect: Yup.string().required('jobTypeSelect Name is required'),
    }),
    validateOnChange: false,
    validateOnBlur: false,
    onSubmit: (values, { resetForm }) => {
      onClose();
      submitOrder(values);
      resetForm();
    },
  });

  const submitOrder = async values => {
    try {
      setOrdersLoading(true);
      const response = await axios.post(endpoints.orders.submit, values);
      if (response.status === 200) {
        refreshOrders();
        toast.success('Order submitted successfully');
      }
    } catch (error) {
      console.error(error.response);
      toast.error('Failed to submit order: ' + error.response.data.error);
    } finally {
      setOrdersLoading(false);
    }
  };

  // Get recipes
  const [recipesLoading, setRecipesLoading] = useState(true);
  const [recipesError, setRecipesError] = useState(null);
  // List Recipes
  const getRecipes = async (id = null) => {
    // maybe add a state to check if its first render not to set recipesLoading
    try {
      setRecipesLoading(true);
      const response = await axios(
        `${endpoints.recipes.list(id || jobTypes[0].id)}`,
      );
      if (response.data.recipes.length === 0) {
        setRecipesError('No Recipes Found');
        formik.setFieldValue('recipe_id', '-1');
      } else {
        setRecipesError(null);
        setFieldOptions(prevOptions => ({
          ...prevOptions,
          recipe_id: response.data.recipes?.map(recipe => ({
            value: recipe.id,
            label: recipe.name,
          })),
        }));
        formik.setFieldValue('recipe_id', response.data.recipes[0].id);
    
      }
    } catch (error) {
      setRecipesError('Error fetching Recipes: ' + error);
      console.error(error);
    } finally {
      setRecipesLoading(false);
    }
  };

  // Monitor changes to the job_type_id value
  useEffect(() => {
    // Clear the recipe_id field
    formik.setFieldValue('kpis', []);
    getRecipes(formik.values.job_type_id);
  }, [formik.values.job_type_id]);

  useEffect(() => {
    formik.setFieldValue('kpis', []);
    if (formik.values.recipe_id !== '-1') {
      getRecipeDetail(formik.values.recipe_id);
    }
  }, [formik.values.recipe_id]);

  // Get Recipe Detail
  const [recipeDetailsLoading, setRecipeDetailsLoading] = useState(true);
  const [recipeDetailsError, setRecipeDetailsError] = useState(false);

  const fillFormikValues = recipe => {
    try {
      // Set the KPIs array with required properties
      const jobTypeKPIs = formik.values.kpis;
      const recipeKPIs = recipe.kpis;
      // Create a map to store KPIs by their ID for efficient merging
      const kpiMap = new Map();

      // Add jobTypeKPIs to the map
      jobTypeKPIs.forEach(kpi => {
        kpiMap.set(String(kpi.id), { ...kpi });
      });
      // Override or add recipeKPIs into the map
      recipeKPIs.forEach(kpi => {
        kpiMap.set(String(kpi.id), { ...kpi });
      });
      // Convert the map values back to an array
      const mergedKPIs = Array.from(kpiMap.values());

      // Set the merged KPIs back to the formik field
      formik.setFieldValue('kpis', mergedKPIs);


      // Set the stop_options array with required properties
      formik.setFieldValue('stop_options', recipe.description);

      // Handle the sources array
      if (recipe.sources && recipe.sources.length > 0) {
        // Map the sources to the required format
        formik.setFieldValue(
          'sources',
          recipe.sources.map((source, index) => ({
            bin_id: '',
            qty_percent: source.percentage,
            source_number: index + 1,
            materialId: source.materialId,
          })),
        );
      } else {
        // If no sources, initialize with a default ingredient
        formik.setFieldValue('sources', []);
      }

      getBinsByFinalProductId(recipe.final_product_id);
      formik.setFieldValue(
        'destinations',
        recipe.destinations?.map((_, index) => ({
          bin_id: '',
          destination_number: index + 1,
          prd_name: '',
          prd_code: '0',
        })),
      );     
    } catch (error) {
      // Rethrow the error to the parent function
      throw new Error(`Error while filling Formik values: ${error.message}`);
    }
  };

  const getRecipeDetail = async id => {
    try {
      setRecipeDetailsLoading(true);
      const response = await axios(`${endpoints.recipes.details(id)}`);
      if (response.data.length === 0) {
        setRecipeDetailsError('No Recipe Details Found');
      } else {
        setRecipeDetailsError(null);
        fillFormikValues(response.data);
      }
    } catch (error) {
      setRecipeDetailsError('Error fetching Recipe Details: ' + error);
      console.error(error);
    } finally {
      setRecipeDetailsLoading(false);
    }
  };

  const [fieldOptions, setFieldOptions] = useState({
    jobTypeSelect: jobTypes.map(job => ({
      value: job.id,
      label: job.name,
    })),
    recipe_id: [],
    destinationSelect: [],
  });
  const getBinsByFinalProductId = finalproduct_id => {
    if (finalproduct_id) {
      setFieldOptions(prevOptions => ({
        ...prevOptions,
        destinationSelect: bins
          .filter(bin => bin.material_id === finalproduct_id) // Filter bins by material_id
          .map(bin => ({
            label: bin.bin_name, // Map bin_name to label
            value: bin.id, // Map id to value
          }))
          .concat(
            bins.filter(bin => bin.material_id === finalproduct_id).length === 0
              ? [{ label: '', value: '' }]
              : [],
          ),
      }));
    } else {
      setFieldOptions(prevOptions => ({
        ...prevOptions,
        destinationSelect: [{ label: '', value: '' }],
      }));
    }
  };

  const addRecipeFormConfig = {
    title: 'Create New Order',
    fields: [
      {
        name: 'job_type_id',
        label: 'Select Job Type: ',
        type: 'select',
        fieldOptions: fieldOptions.jobTypeSelect,
      },
      {
        name: 'recipe_id',
        label: 'Select Recipe Name',
        type: 'select',
        fieldOptions: fieldOptions.recipe_id,
      },
    ],

    actionName: 'Submit Order',
  };
  const { title, desc, fields, actionName } = addRecipeFormConfig;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth={true}
      maxWidth="lg"
      className="p-4"
    >
      {recipesLoading ? (
        <LoadingScreen/>
      ) : (
        <>                
          {/* Modal Header */}
          {title && (
            <DialogTitle className="text-lg font-bold">{title}</DialogTitle>
          )}
          {/* Modal Content */}
          <DialogContent className="flex flex-col gap-4">
            {desc && <p className="text-gray-600">{desc}</p>}

            {/* Render Formik Fields */}
            <SelectField
              formik={formik}
              labelName={fields[0].label}
              field={fields[0].name}
              className="w-full lg:w-1/3"
              options={fields[0].fieldOptions}
            />
            {recipesError ? (
              <ErrorScreen
                message={recipesError}
                handleRefresh={() => getRecipes(formik?.values?.job_type_id)}
              />
            ) : (
              <SelectField
                formik={formik}
                labelName={fields[1].label}
                field={fields[1].name}
                className="w-full lg:w-1/3"
                options={fields[1].fieldOptions}
              />
            )}

            {recipeDetailsLoading ? (
              <LoadingScreen/>
            ) : recipeDetailsError || recipesError ? (
              <ErrorScreen
                message={recipeDetailsError || recipesError}
                handleRefresh={
                  recipeDetailsError
                    ? () => getRecipeDetail(formik.values.recipe_id)
                    : () => getRecipes(formik?.values?.job_type_id)
                }
              />
            ) : (
              <>
                {/* KPIs Section */}
                <Box className="border border-zinc-300 dark:border-zinc-600 p-4 rounded-lg">
                  <h3 className="text-xl font-semibold mb-2 text-center">
                    Key Performance Indicators (KPIs)
                  </h3>
                  <FlexContainer>
                    {formik.values.kpis?.map((kpi, index) => (
                      <FlexItem
                        key={index}
                        borderColor="border-zinc-300 dark:border-zinc-600"
                      >
                        <h4 className="text-center font-bold mb-2">
                          {kpi.kpi_name}
                        </h4>
                        {kpi.data_type?.toLowerCase() === 'boolean' ? (
                          // Render MUI Checkbox for boolean fields
                          <Checkbox
                            checked={formik.values.kpis[index]?.value || false} // Handle default value
                            onChange={e =>
                              formik.setFieldValue(
                                `kpis[${index}].value`,
                                e.target.checked,
                              )
                            }
                            className="m-0"
                          />
                        ) : (
                          // Render InputField for other data types
                          <InputField
                            type={
                              kpi.data_type?.toLowerCase() === 'string'
                                ? 'text'
                                : kpi.data_type?.toLowerCase() === 'integer' ||
                                  kpi.data_type?.toLowerCase() === 'float'
                                ? 'number'
                                : 'text' // Default fallback
                            }
                            formik={formik}
                            field={`kpis[${index}].value`} // Dynamically bind the value field
                            className="w-3/4 m-0"
                            defaultValue={kpi.value} // Set initial value for the input
                          />
                        )}
                      </FlexItem>
                    ))}
                  </FlexContainer>
                </Box>

                {/* Sources Section */}
                <Box className="border border-zinc-300 dark:border-zinc-600 p-4 rounded-lg">
                  <h3 className="text-xl font-semibold mb-2 text-center">
                    Sources
                  </h3>
                  <FlexContainer>
                    {formik.values.sources?.map((source, index) => (
                      <FlexItem
                        key={source.source_number}
                        borderColor="border-zinc-300 dark:border-zinc-600"
                        className="p-4 rounded-lg"
                      >
                        {/* Source Header */}
                        <h4 className="text-center font-bold mb-2">{`Source ${
                          index + 1
                        } `}</h4>

                        {/* SelectField for Bin Selection */}
                        <SelectField
                          formik={formik}
                          field={`sources[${index}].bin_id`} // Make the field unique with source_number
                          options={
                            binsByMaterialId[+source.materialId] || [
                              { label: '', value: '' },
                            ]
                          }
                        />

                        {/* InputField for Percentage */}
                        <InputField
                          formik={formik}
                          labelName=""
                          type="number"
                          field={`sources[${index}].qty_percent`} // Make the field unique with source_number
                          defaultValue={source.qty_percent} // Set the default value to qty_percent
                          className="text-center text-lg"
                        />
                      </FlexItem>
                    ))}
                  </FlexContainer>
                </Box>

                {/* Destination Section */}
                <Box className="border border-zinc-300 dark:border-zinc-600 p-4 rounded-lg">
                  <h3 className="text-xl font-semibold mb-2 text-center">
                    Destinations
                  </h3>
                  <FlexContainer>
                    {formik.values.destinations?.map((destination, index) => (
                      <FlexItem
                        key={index}
                        borderColor="border-zinc-300 dark:border-zinc-600"
                      >
                        <h4 className="text-center font-bold mb-2">
                          Destination {destination.destination_number}
                        </h4>
                        {/* Select Field for Bin */}
                        <SelectField
                          key={index}
                          formik={formik}
                          field={`destinations[${index}].bin_id`} // unique field name
                          options={fieldOptions.destinationSelect}
                        />
                      </FlexItem>
                    ))}
                  </FlexContainer>
                </Box>
              </>
            )}
          </DialogContent>

          {/* Modal Actions */}
          <DialogActions>
            <Button
              onClick={formik.handleSubmit}
              variant="contained"
              className="bg-blue-600 text-white hover:bg-blue-700"
            >
              {actionName}
            </Button>
            <Button
              onClick={onClose}
              variant="outlined"
              className="border-gray-300 text-gray-800 hover:bg-gray-100"
            >
              Cancel
            </Button>
          </DialogActions>
        </>
      )}
    </Dialog>
  );
};

export default BPPopupModal;
