import { styled, useTheme } from '@mui/material/styles';
import MuiDrawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import { Box, Tooltip } from '@mui/material';
import { menuItems, bluePrint } from '../../Data/Navbar';
import { NavbarContext } from '../../Context/NavbarContext';
import { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { AuthContext } from '../../Context/AuthProvider';

const drawerWidth = 240;

const openedMixin = theme => ({
  width: drawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
});

const closedMixin = theme => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: prop => prop !== 'open',
})(({ theme }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: 'nowrap',
  boxSizing: 'border-box',
  variants: [
    {
      props: ({ open }) => open,
      style: {
        ...openedMixin(theme),
        '& .MuiDrawer-paper': openedMixin(theme),
      },
    },
    {
      props: ({ open }) => !open,
      style: {
        ...closedMixin(theme),
        '& .MuiDrawer-paper': closedMixin(theme),
      },
    },
  ],
}));

export default function SideNav() {
  const { open } = useContext(NavbarContext);
  const { auth } = useContext(AuthContext);

  return (
    <>
      <Box sx={{ display: 'flex' }}>
        <Drawer
          variant="permanent"
          open={open}
          PaperProps={{
            className:
              'dark:!bg-zinc-800 dark:!text-zinc-300 !bg-zinc-300 2xl:!pt-10 pt-7',
          }}
        >
          <DrawerHeader></DrawerHeader>
          <List>
            {menuItems.map(
              (item, index) =>
                item.roles.includes(auth.role) && (
                  <ListItem
                    key={item.name}
                    disablePadding
                    sx={{ display: 'block' }}
                  >
                    <NavLink
                      to={item.link}
                      className={({ isActive }) =>
                        `inline-block w-full transition-all duration-300 ease-in-out ${
                          isActive
                            ? 'bg-zinc-600 dark:bg-zinc-200 text-zinc-100 dark:text-zinc-800 hover:!bg-zinc-500 dark:hover:!bg-zinc-400'
                            : 'dark:hover:!bg-zinc-700 hover:!bg-zinc-400'
                        }`
                      }
                    >
                      <Tooltip
                        title={
                          <span className="2xl:!text-lg">{item.tooltip}</span>
                        }
                        placement="top"
                        arrow
                        disableInteractive
                        slotProps={{
                          popper: { className: `${open ? 'hidden' : ''}` },
                        }}
                      >
                        <ListItemButton
                          sx={[
                            { minHeight: 48, px: 2.5 },
                            open
                              ? { justifyContent: 'initial' }
                              : { justifyContent: 'center' },
                          ]}
                          className="last:2xl:!mb-1 !py-6 2xl:!py-7"
                        >
                          <div
                            className={`flex justify-center items-center ${
                              open ? 'mr-3' : 'mr-auto'
                            }`}
                          >
                            <item.icon className="text-xl md:text-2xl 2xl:!text-3xl" />
                          </div>
                          <span
                            className={`text-xl 2xl:!text-2xl ml-3 ${
                              open ? 'inline' : 'hidden'
                            }`}
                          >
                            {item.name}
                          </span>
                        </ListItemButton>
                      </Tooltip>
                    </NavLink>
                  </ListItem>
                ),
            )}
          </List>
          <Divider className="dark:!bg-zinc-600" />
          <List>
            <ListItem disablePadding sx={{ display: 'block' }}>
              <NavLink
                to={bluePrint.link}
                className={({ isActive }) =>
                  `inline-block w-full transition-all duration-300 ease-in-out ${
                    isActive
                      ? 'bg-blue-400 dark:bg-blue-800 text-zinc-900 dark:text-gray-100 hover:!bg-blue-500 dark:hover:!bg-blue-600'
                      : 'dark:hover:!bg-zinc-700 hover:!bg-zinc-400'
                  }`
                }
              >
                <Tooltip
                  title={
                    <span className="2xl:!text-lg ">{bluePrint.tooltip}</span>
                  }
                  placement="top"
                  arrow
                  disableInteractive
                  slotProps={{
                    popper: { className: `${open ? 'hidden' : ''}` },
                  }}
                >
                  <ListItemButton
                    sx={[
                      { minHeight: 48, px: 2.5 },
                      open
                        ? { justifyContent: 'initial' }
                        : { justifyContent: 'center' },
                    ]}
                    className="!py-6 2xl:!py-7"
                  >
                    <div
                      className={`flex justify-center items-center ${
                        open ? 'mr-3' : 'mr-auto'
                      }`}
                    >
                      <bluePrint.icon className="text-xl md:text-2xl 2xl:!text-3xl" />
                    </div>
                    <span
                      className={`text-xl 2xl:!text-2xl ml-3 ${
                        open ? 'inline' : 'hidden'
                      }`}
                    >
                      {bluePrint.name}
                    </span>
                  </ListItemButton>
                </Tooltip>
              </NavLink>
            </ListItem>
          </List>
        </Drawer>
      </Box>
    </>
  );
}
