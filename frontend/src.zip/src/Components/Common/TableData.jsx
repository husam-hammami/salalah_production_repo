import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import {
  Checkbox,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
} from '@mui/material';
import ActionButton from './ActionButton';
import { useContext, useState } from 'react';
import { Roles } from '../../Data/Roles';
import { AuthContext } from '../../Context/AuthProvider';

function TableData({ headers, data, dataKeys, actions, useFilter }) {
  const { auth } = useContext(AuthContext);

  const [filter, setFilter] = useState(useFilter?.options[0].value || ''); // Filter state
  const handleFilterChange = async event => {
    setFilter(event.target.value);
  };

  return (
    <Paper className="w-full mt-5 !bg-zinc-100 dark:!bg-zinc-800 !rounded-lg">
      <TableContainer
        className="overflow-x-auto rounded-lg shadow-md"
        sx={{ minWidth: 550 }}
      >
        {useFilter && (
          <div className="flex justify-center items-center p-2">
            <>
              <span className="me-2">Filter By: </span>
              <FormControl variant="outlined" className="w-48">
                <InputLabel>{useFilter.filterName}</InputLabel>
                <Select
                  value={filter}
                  onChange={handleFilterChange}
                  label="Filter By"
                >
                  {useFilter.options?.map((option, index) => (
                    <MenuItem key={index} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </>
          </div>
        )}
        <Table className="md:table-fixed w-full">
          {/* ________ Table Heading ____________ */}
          <TableHead className="p-3 bg-zinc-400 dark:bg-zinc-700">
            <TableRow>
              {headers?.map((row, index) => (
                <TableCell
                  className="2xl:!text-xl !font-bold 2xl:!tracking-widest !tracking-wider text-zinc-900 dark:text-zinc-100 max-2xl:!py-2"
                  key={index}
                >
                  {row}
                </TableCell>
              ))}
              {actions && (
                <TableCell className="2xl:!text-xl !font-bold 2xl:!tracking-widest !tracking-wider text-zinc-900 dark:text-zinc-100 max-2xl:!py-2">
                  Actions
                </TableCell>
              )}
            </TableRow>
          </TableHead>

          {/* ________ Table Body ____________ */}
          <TableBody>
            {data && data?.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={headers.length + (actions ? 1 : 0)}
                  className="text-center text-lg text-gray-600 dark:text-gray-400"
                >
                  <div className="flex flex-col w-full items-center justify-center py-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-16 w-16 text-gray-400 dark:text-gray-500"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M9 17v2a1 1 0 001 1h4a1 1 0 001-1v-2m-6 0a4 4 0 018 0m-6 0v-2a4 4 0 011-2.917m3 2.917V9a4 4 0 00-8 0v2.083a4 4 0 001 2.917m4-6.583V7m0 4h.01"
                      />
                    </svg>
                    <h1 className="mt-4 text-xl font-medium text-gray-600 dark:text-gray-300">
                      No Data Available
                    </h1>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              data &&
              data?.map(row => (
                <TableRow
                  className={`transition-all duration-300 ease-in-out dark:hover:bg-zinc-600 hover:bg-zinc-300 ${
                    auth.username === row.username &&
                    auth.id === row.id &&
                    'bg-gray-200 dark:bg-gray-800'
                  }`}
                  key={row.id}
                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                >
                  {dataKeys?.map((key, index) => (
                    <TableCell
                      className="2xl:!text-xl dark:text-zinc-200 text-zinc-900 max-2xl:!py-1"
                      key={index}
                    >
                      {typeof row[key] === 'boolean' ? (
                        <Checkbox
                          checked={row[key]}
                          disabled
                          className={`opacity-50 ${
                            row[key] ? '!text-green-600' : '!text-zinc-200'
                          }`}
                        />
                      ) : (
                        row[key]
                      )}
                    </TableCell>
                  ))}
                  {actions && (
                    <TableCell className="2xl:!text-xl font-semibold text-zinc-900 dark:text-zinc-100 max-2xl:!py-1">
                      <div className="space-x-2 flex 2xl:space-x-4">
                        {auth.username === row.username && auth.id === row.id
                          ? 'You'
                          : row.role === Roles.Admin
                          ? 'Admin'
                          : actions.map((action, index) => (
                              <div className="action-button" key={index}>
                                <ActionButton
                                  name={action.name}
                                  icon={action.icon}
                                  action={action.action}
                                  id={row.id}
                                  className={action.className}
                                />
                              </div>
                            ))}
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}

export default TableData;
