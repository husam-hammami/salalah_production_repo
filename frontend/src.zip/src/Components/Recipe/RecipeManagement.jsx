import { toast } from 'react-toastify';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import {
  Box,
  Checkbox,
  MenuItem,
  Paper,
  Select,
  Switch,
  TextField,
  Typography,
} from '@mui/material';
import { IoAddOutline } from 'react-icons/io5';
import { FaMinus, FaPlus, FaSave } from 'react-icons/fa';
import { MdDelete } from 'react-icons/md';
import CircularButton from '../Common/CircularButton';
import InputField from '../Common/InputField';
import SelectField from '../Common/SelectField';
import { useContext, useEffect, useState } from 'react';
import ActionButton from '../Common/ActionButton';
import PopupModal from './PopupModal';
import { recipeFormConfig } from '../../Data/Recipe';
import { JobTypesContext } from '../../Context/ApiContext/JobTypesContext';
import { MaterialsContext } from '../../Context/ApiContext/MaterialsContext';
import endpoints from '../../API/endpoints';
import axios from '../../API/axios';
import ErrorScreen from '../Common/ErrorScreen';
import LoadingScreen from '../Common/LoadingScreen';
import ConfirmationModal from '../Common/ConfirmationModal';

function RecipeManagement() {
  const [recipesLoading, setRecipesLoading] = useState(true);
  const [recipesError, setRecipesError] = useState(null);
  // List Contextd
  const { jobTypes } = useContext(JobTypesContext);
  const { materials } = useContext(MaterialsContext);

  const ingredientsOptions = materials
    .filter(item => item.category.includes('IN') && item.is_released) // Filter materials with "OUT" in category
    .map(item => ({
      label: item.material_name + ` (${item.material_code})`,
      value: item.id,
    }));
  const [fieldOptions, setFieldOptions] = useState({
    recipeId: [],
    jobTypeId: jobTypes.map(job => ({
      value: job.id,
      label: job.name,
    })),
    finalProductId: materials
      .filter(item => item.category.includes('OUT') && item.is_released) // Filter materials with "OUT" in category
      .map(item => ({
        label: item.material_name + ` (${item.material_code})`,
        value: item.id,
      })),
  });
  const formik = useFormik({
    initialValues: {
      sources: [],
      destinations: [],
      kpis: [],
      jobTypeId: jobTypes[0].id,
      recipeId: '-1',
      finalProductId: '',
      is_released: false,
      description: {
        jobQti: false,
        fullDest: false,
        emptySource: false,
        heldStatus: false,
        heldStatusDelay: 0,
        autoStopDelay: 0,
      },
    },
    validationSchema: Yup.object({
      // jobTypeId: Yup.string().required('jobTypeId Name is required'),
      // recipeId: Yup.string().required('recipeId Name is required'),
      // newRecipeName: Yup.string().required('newRecipeName Name is required'),
      // jobTypeSelect: Yup.string().required('jobTypeSelect Name is required'),
      finalProductId: Yup.string()
        .required('Final Product is required')
        .notOneOf([''], 'Final Product is required'),
      // jobQti: Yup.boolean().required('jobQti Name is required'),
      // fullDest: Yup.boolean().required('fullDest Name is required'),
      // emptySource: Yup.boolean().required('emptySource is required'),
      // heldStatus: Yup.boolean().required('heldStatus is required'),
      // heldStatusDelay: Yup.string().required('heldStatusDelay is required'),
      // autoStopDelay: Yup.string().required('autoStopDelay Name is required'),
    }),
    validateOnChange: false,
    validateOnBlur: false,
    onSubmit: values => {
      updateRecipe(values);
    },
  });

  const [saveLoading, setSaveLoading] = useState(false);
  const updateRecipe = async values => {
    try {
      setSaveLoading(true);
      const response = await axios.post(endpoints.recipes.update, values);
      if (response.status === 200) {
        toast.success('Recipe Updated successfully');
      }
    } catch (error) {
      console.error(error.response);
      toast.error('Failed to update recipe: ' + error.response.data.error);
    } finally {
      setSaveLoading(false);
    }
  };

  // List Recipes
  const getRecipes = async (id = null) => {
    // maybe add a state to check if its first render not to set recipesLoading
    try {
      setRecipesLoading(true);
      const response = await axios(
        `${endpoints.recipes.list(id || jobTypes[0].id)}`,
      );
      formik.setFieldValue(
        'kpis',
        response.data?.kpis?.map(kpi => ({
          id: kpi.id,
          kpi_name: kpi.kpi_name,
          value: kpi.default_value,
          data_type: kpi.data_type,
          unit: kpi.unit,
        })),
      );
      if (response.data.recipes.length === 0) {
        setRecipesError('No Recipes Found');
        formik.setFieldValue('recipeId', '-1');
      } else {
        setRecipesError(null);
        setFieldOptions(prevOptions => ({
          ...prevOptions,
          recipeId: response.data.recipes?.map(recipe => ({
            value: recipe.id,
            label: recipe.name,
          })),
        }));
        formik.setFieldValue('recipeId', response.data.recipes[0].id);
        await getRecipeDetail(response.data.recipes[0].id);
      }
    } catch (error) {
      setRecipesError('Error fetching Recipes: ' + error);
      console.error(error);
    } finally {
      setRecipesLoading(false);
    }
  };

  // Monitor changes to the jobTypeId value
  useEffect(() => {
    // Clear the recipeId field
    formik.setFieldValue('kpis', []);
    getRecipes(formik.values.jobTypeId);
  }, [formik.values.jobTypeId]);

  useEffect(() => {
    formik.setFieldValue('kpis', []);
    if (formik.values.recipeId !== '-1') {
      getRecipeDetail(formik.values.recipeId);
    }
  }, [formik.values.recipeId]);

  // Get Recipe Detail
  const [recipeDetailsLoading, setRecipeDetailsLoading] = useState(true);
  const [recipeDetailsError, setRecipeDetailsError] = useState(false);

  const fillFormikValues = recipe => {
    try {
      // Set the final product field
      formik.setFieldValue('finalProductId', recipe.final_product_id || '');

      // Set the is_released field
      formik.setFieldValue('is_released', recipe.released);

      // Set the KPIs array with required properties
      const jobTypeKPIs = formik.values.kpis;
      const recipeKPIs = recipe.kpis;
      // Create a map to store KPIs by their ID for efficient merging
      const kpiMap = new Map();

      // Add jobTypeKPIs to the map
      jobTypeKPIs.forEach(kpi => {
        kpiMap.set(String(kpi.id), { ...kpi });
      });
      // Override or add recipeKPIs into the map
      recipeKPIs.forEach(kpi => {
        kpiMap.set(String(kpi.id), { ...kpi });
      });
      // Convert the map values back to an array
      const mergedKPIs = Array.from(kpiMap.values());

      // Set the merged KPIs back to the formik field
      formik.setFieldValue('kpis', mergedKPIs);

      // Handle the sources array
      if (recipe.sources && recipe.sources.length > 0) {
        // Map the sources to the required format
        formik.setFieldValue(
          'sources',
          recipe.sources.map(ingredient => ({
            materialId: ingredient.materialId,
            percentage: ingredient.percentage,
          })),
        );
      } else {
        // If no sources, initialize with a default ingredient
        formik.setFieldValue('sources', [
          {
            materialId: ingredientsOptions[0]?.value || '',
            percentage: 100,
          },
        ]);
      }

      // Handle the destinations array
      if (recipe.destinations && recipe.destinations.length > 0) {
        // Set the destinations directly as an array of numbers (IDs)
        formik.setFieldValue('destinations', recipe.destinations);
      } else {
        // If no destinations, initialize with a default destination ID of 1
        formik.setFieldValue('destinations', [1]);
      }
    } catch (error) {
      // Rethrow the error to the parent function
      throw new Error(`Error while filling Formik values: ${error.message}`);
    }
  };

  const getRecipeDetail = async id => {
    try {
      setRecipeDetailsLoading(true);
      const response = await axios(`${endpoints.recipes.details(id)}`);
      if (response.data.length === 0) {
        setRecipeDetailsError('No Recipe Details Found');
      } else {
        setRecipeDetailsError(null);
        fillFormikValues(response.data);
      }
    } catch (error) {
      setRecipeDetailsError('Error fetching Recipe Details: ' + error);
      console.error(error);
    } finally {
      setRecipeDetailsLoading(false);
    }
  };

  // Add Recipe
  const [isModalOpen, setModalOpen] = useState(false);
  const handleOpenModal = () => setModalOpen(true);
  const handleCloseModal = () => setModalOpen(false);

  // Delete Recipe
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const cancelDelete = () => {
    setIsDeleteModalOpen(false); // Close the modal without deleting
  };
  const removeRecipe = async id => {
    try {
      setIsDeleteModalOpen(false);
      // setMaterialLoading(true);
      const response = await axios.delete(endpoints.recipes.delete(id));
      if (response.status === 200) {
        getRecipes(formik.values.jobTypeId);
        toast.success('The recipe has been deleted.');
      }
    } catch (error) {
      console.error(error.response);
      toast.error('Failed to remove recipe: ' + error.response.data.error);
    }
  };

  // Ingredient
  // Add new ingredient
  const handleAddIngredient = () => {
    const currentSources = formik.values.sources || [];
    if (currentSources.length < 5) {
      const newIngredient = {
        materialId: ingredientsOptions[0].value,
        percentage: 0,
      };
      formik.setFieldValue('sources', [...currentSources, newIngredient]);
    }
  };
  // Remove last ingredient
  const handleRemoveIngredient = () => {
    const currentSources = formik.values.sources || [];
    if (currentSources.length > 1) {
      const updatedSources = currentSources.slice(0, -1);
      formik.setFieldValue('sources', updatedSources);
    }
  };

  // Destinations
  // Add new destination
  const handleAddDestination = () => {
    const currentDestinations = formik.values.destinations || [];
    if (currentDestinations.length < 5) {
      const newDestination = currentDestinations.length + 1; // Generate the next number
      formik.setFieldValue('destinations', [
        ...currentDestinations,
        newDestination,
      ]);
    }
  };

  // Remove last destination
  const handleRemoveDestination = () => {
    const currentDestinations = formik.values.destinations || [];
    if (currentDestinations.length > 1) {
      const updatedDestinations = currentDestinations.slice(0, -1);
      formik.setFieldValue('destinations', updatedDestinations);
    }
  };

  return (
    <>
      {recipesLoading ? (
        <LoadingScreen />
      ) : (
        <>
          {saveLoading && <LoadingScreen />}
          <Box
            component="fieldset"
            className="mx-auto max-w-6xl border border-stone-300 dark:border-gray-700 px-6 pt-0 pb-2 rounded-lg mb-3"
          >
            <Typography component="legend">
              <h3 className="p-3 dark:bg-zinc-800 rounded-lg text-2xl font-mono text-zinc-900 dark:text-zinc-50">
                {recipeFormConfig.title}
              </h3>
            </Typography>
            <form className="flex flex-wrap flex-col gap-6 lg:gap-0">
              <div className="recipes flex flex-col w-full mt-3 gap-y-5">
                {/* ________________ Recipe Data & buttons _________________ */}
                <div className="recipe-data-buttons md:flex justify-between">
                  {/* Submit Buttons */}
                  <div className="flex order-2 max-md:justify-end self-start items-center gap-x-3 max-sm:justify-center w-full lg:w-auto">
                    <CircularButton
                      action={handleOpenModal}
                      type="button"
                      icon={IoAddOutline}
                      tooltip="Add Recipe"
                      className={
                        '!text-zinc-100 p-2 !bg-green-900 hover:!bg-green-800 dark:!bg-green-700 dark:hover:!bg-green-600 hover:!text-zinc-100'
                      }
                      size={55}
                    />
                    {!recipesError && (
                      <>
                        <CircularButton
                          action={formik.handleSubmit}
                          icon={FaSave}
                          tooltip="Save Recipe"
                          className={
                            '!text-zinc-100 p-2 !bg-blue-900 hover:!bg-blue-800 dark:!bg-blue-700 dark:hover:!bg-blue-600 hover:!text-zinc-100'
                          }
                          size={55}
                        />
                        <CircularButton
                          icon={MdDelete}
                          action={() => setIsDeleteModalOpen(true)}
                          tooltip="Remove Recipe"
                          type="button"
                          className={
                            '!text-zinc-100 p-2 bg-red-900  hover:!bg-red-700 dark:!bg-red-700 dark:hover:!bg-red-600 hover:!text-zinc-100'
                          }
                          size={55}
                        />
                      </>
                    )}
                  </div>

                  {/* ________________ Recipe control _________________ */}
                  <div className="order-1 flex-1 recipe-control space-y-4">
                    {/* _________________________ Recipe Info _____________________ */}
                    <div className="recipe-info flex-1 flex-wrap gap-4 lg:flex-nowrap ">
                      <div className="flex flex-wrap gap-4 lg:flex-nowrap items-end">
                        {/* Name Field */}
                        <SelectField
                          formik={formik}
                          labelName={recipeFormConfig.recipeControl[0].label}
                          field={recipeFormConfig.recipeControl[0].name}
                          className="w-full lg:w-1/3"
                          options={
                            fieldOptions[recipeFormConfig.recipeControl[0].name]
                          }
                        />
                        {recipesError ? (
                          <ErrorScreen
                            message={
                              recipesError + ', Please add a recipe first'
                            }
                            handleRefresh={() =>
                              getRecipes(formik?.values?.jobTypeId)
                            }
                          />
                        ) : (
                          <SelectField
                            formik={formik}
                            labelName={recipeFormConfig.recipeControl[1].label}
                            field={recipeFormConfig.recipeControl[1].name}
                            className="w-full lg:w-1/3"
                            options={
                              fieldOptions[
                                recipeFormConfig.recipeControl[1].name
                              ]
                            }
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {recipesError ? (
                  ''
                ) : recipeDetailsLoading ? (
                  <LoadingScreen />
                ) : recipeDetailsError ? (
                  <ErrorScreen
                    message={recipeDetailsError}
                    handleRefresh={
                      recipeDetailsError
                        ? () => getRecipeDetail(formik.values.recipeId)
                        : () => getRecipes(formik?.values?.jobTypeId)
                    }
                  />
                ) : (
                  <>
                    {/* _________________________ Recipe data _____________________ */}
                    <div className="recipe-data">
                      <h4 className="font-medium mb-2"> Data: </h4>
                      <div className="flex items-center flex-wrap gap-6 max-sm:gap-2">
                        <div className="flex flex-col">
                          <label
                            htmlFor={recipeFormConfig.recipeData[0].name}
                            className="dark:text-zinc-50 mb-1"
                          >
                            {recipeFormConfig.recipeData[0].label}
                          </label>
                          <TextField
                            id={recipeFormConfig.recipeData[0].name}
                            name={recipeFormConfig.recipeData[0].name}
                            variant="outlined"
                            size="small"
                            disabled={recipeFormConfig.recipeData[0].disabled}
                            value={formik.values.recipeId || '-1'} // You can set the default value like this
                            onChange={formik?.handleChange}
                            onBlur={formik?.handleBlur}
                            error={
                              formik?.touched[
                                recipeFormConfig.recipeData[0].name
                              ] &&
                              Boolean(
                                formik?.errors[
                                  recipeFormConfig.recipeData[0].name
                                ],
                              )
                            }
                            helperText={
                              formik?.touched[
                                recipeFormConfig.recipeData[0].name
                              ] &&
                              formik.errors[recipeFormConfig.recipeData[0].name]
                            }
                            className={`w-full ${recipeFormConfig.recipeData[0].className}`}
                          />
                        </div>
                        <div className="flex flex-col w-1/3">
                          {recipeFormConfig.recipeData[1].label && (
                            <label
                              htmlFor={recipeFormConfig.recipeData[1].name}
                              className="dark:text-zinc-50 mb-1"
                            >
                              {recipeFormConfig.recipeData[1].label}
                            </label>
                          )}
                          <Select
                            value={formik.values.finalProductId || ''} // Set default value
                            size="small"
                            id={recipeFormConfig.recipeData[1].name}
                            name={recipeFormConfig.recipeData[1].name}
                            onChange={formik?.handleChange}
                            onBlur={formik?.handleBlur}
                          >
                            <MenuItem disabled value="" className="!hidden">
                              <em>None</em>
                            </MenuItem>
                            {fieldOptions.finalProductId.map(
                              (option, index) => (
                                <MenuItem key={index} value={option.value}>
                                  {option.label}
                                </MenuItem>
                              ),
                            )}
                          </Select>
                          {formik?.touched[
                            recipeFormConfig.recipeData[1].name
                          ] &&
                            formik?.errors[
                              recipeFormConfig.recipeData[1].name
                            ] && (
                              <span className="text-red-500 text-sm">
                                {
                                  formik.errors[
                                    recipeFormConfig.recipeData[1].name
                                  ]
                                }
                              </span>
                            )}
                        </div>

                        <label className="flex items-center">
                          <Switch
                            checked={formik.values.is_released}
                            onChange={e =>
                              formik.setFieldValue(
                                'is_released',
                                e.target.checked,
                              )
                            }
                          />
                          <span
                            className={`ml-2 font-semibold text-xl ${
                              formik.values.is_released
                                ? 'text-green-700 dark:text-green-500'
                                : 'text-red-700 dark:text-red-500'
                            }`}
                          >
                            {formik.values.is_released
                              ? 'Released'
                              : 'Not Released'}
                          </span>
                        </label>
                      </div>
                    </div>
                    {/* _________________________ Recipe Kpi _____________________ */}
                    <div className="recipe-kpi">
                      <h4 className="font-medium mb-2"> Kpis: </h4>
                      <div className="flex flex-wrap gap-6 max-sm:gap-2">
                        {formik.values.kpis?.map((kpi, index) => (
                          <Paper
                            key={kpi.id}
                            className="flex !w-40 sm:!w-48 items-center flex-col px-0 py-3 !rounded-2xl shadow-md !transition-all !duration-200 !ease-in-out !bg-zinc-100 dark:!bg-zinc-800 dark:hover:!bg-zinc-700 hover:!bg-zinc-300"
                          >
                            {/* KPI Card */}
                            <h4 className="mb-1">
                              {kpi.kpi_name} ({kpi.unit})
                            </h4>
                            {kpi.data_type?.toLowerCase() === 'boolean' ? (
                              // Render MUI Checkbox for boolean fields
                              <Checkbox
                                checked={
                                  formik.values.kpis[index]?.value
                                    ? true
                                    : false
                                } // Handle default value
                                onChange={e =>
                                  formik.setFieldValue(
                                    `kpis[${index}].value`,
                                    e.target.checked,
                                  )
                                }
                                className="m-0"
                              />
                            ) : (
                              // Render InputField for other data types
                              <InputField
                                type={
                                  kpi.data_type?.toLowerCase() === 'string'
                                    ? 'text'
                                    : kpi.data_type?.toLowerCase() ===
                                        'integer' ||
                                      kpi.data_type?.toLowerCase() === 'float'
                                    ? 'number'
                                    : 'text' // Default fallback
                                }
                                formik={formik}
                                field={`kpis[${index}].value`} // Dynamically bind the value field
                                className="w-3/4 m-0"
                                defaultValue={kpi.value} // Set initial value for the input
                              />
                            )}
                          </Paper>
                        ))}
                      </div>
                    </div>

                    {/* ________________ Raw Ingredients _________________ */}
                    <div className="raw-ingredients">
                      <h4 className="mb-2 font-medium"> Raw Ingredients: </h4>
                      <div className="ingredients-container flex justify-between items-center">
                        <div className="flex flex-wrap gap-6 lg:flex-nowrap 2xl:gap-x-8">
                          {formik.values.sources?.map((ingredient, index) => (
                            <Paper
                              key={index}
                              className="flex items-center space-y-3 flex-col px-0 py-3 !rounded-2xl shadow-md !transition-all !duration-200 !ease-in-out !bg-zinc-100 dark:!bg-zinc-800 dark:hover:!bg-zinc-700 hover:!bg-zinc-300"
                            >
                              <h4>Ingredient {index + 1}</h4>

                              {/* Material Select Field */}
                              <SelectField
                                formik={formik}
                                field={`sources[${index}].materialId`} // Dynamically bind to sources array
                                defaultValue={ingredient.materialId} // Initial value
                                className="w-3/4"
                                options={ingredientsOptions}
                              />

                              {/* Percentage Input Field */}
                              <div className="flex relative justify-center items-center">
                                <InputField
                                  type="number"
                                  formik={formik}
                                  field={`sources[${index}].percentage`} // Dynamically bind to sources array
                                  defaultValue={ingredient.percentage} // Initial value
                                  className="w-3/4"
                                />
                                <span className="absolute end-1/3">%</span>
                              </div>
                            </Paper>
                          ))}
                        </div>
                        <div className="ingredients-control flex flex-col sm:space-y-2 space-y-3">
                          {/* Add Ingredient Button */}
                          <ActionButton
                            className="h-10 w-10 !bg-zinc-600 !text-zinc-100 dark:!bg-zinc-200 dark:!text-zinc-900 hover:!bg-zinc-400 hover:!text-zinc-600 dark:hover:!bg-zinc-600 dark:hover:!text-zinc-200 "
                            icon={FaPlus}
                            tooltip="Add Ingredient"
                            iconSize="sm:!text-xl !text-lg"
                            action={handleAddIngredient}
                          />

                          {/* Remove Ingredient Button */}
                          <ActionButton
                            className="h-10 w-10 !bg-zinc-600 !text-zinc-100 dark:!bg-zinc-200 dark:!text-zinc-900 hover:!bg-zinc-400 hover:!text-zinc-600 dark:hover:!bg-zinc-600 dark:hover:!text-zinc-200 "
                            icon={FaMinus}
                            tooltip="Remove Ingredient"
                            iconSize="sm:!text-xl !text-lg"
                            action={handleRemoveIngredient}
                          />
                        </div>
                      </div>
                    </div>

                    {/* ________________ Destination _________________ */}
                    <div className="destination">
                      <h4 className="font-medium"> Destination: </h4>
                      <div className="destination-container flex justify-between items-center">
                        <div className="flex flex-wrap lg:flex-nowrap gap-x-6 2xl:gap-x-8 max-md:gap-y-2">
                          {formik.values.destinations.map(
                            (destination, index) => (
                              <Paper
                                key={index}
                                className="!rounded-2xl shadow-md !transition-all !duration-200 !ease-in-out !bg-zinc-100 dark:!bg-zinc-800 dark:hover:!bg-zinc-700 hover:!bg-zinc-300 py-3 px-4"
                              >
                                {/* Dynamic Destination */}
                                <h4 className="mb-1">
                                  Destination {index + 1}
                                </h4>
                              </Paper>
                            ),
                          )}
                        </div>
                        <div className="destination-control flex flex-col sm:space-y-2 space-y-3">
                          <ActionButton
                            className="h-10 w-10 !bg-zinc-600 !text-zinc-100 dark:!bg-zinc-200 dark:!text-zinc-900 hover:!bg-zinc-400 hover:!text-zinc-600 dark:hover:!bg-zinc-600 dark:hover:!text-zinc-200"
                            icon={FaPlus}
                            tooltip="Add Destination"
                            action={handleAddDestination}
                            iconSize="sm:!text-xl !text-lg"
                          />
                          <ActionButton
                            className="h-10 w-10 !bg-zinc-600 !text-zinc-100 dark:!bg-zinc-200 dark:!text-zinc-900 hover:!bg-zinc-400 hover:!text-zinc-600 dark:hover:!bg-zinc-600 dark:hover:!text-zinc-200"
                            icon={FaMinus}
                            tooltip="Remove Destination"
                            action={handleRemoveDestination}
                            iconSize="sm:!text-xl !text-lg"
                          />
                        </div>
                      </div>
                    </div>

                    {/* ________________ Description _________________ */}
                    <div className="description">
                      <h4 className="font-medium"> Stop Options: </h4>
                      <div className="description-container flex justify-between items-center">
                        <div className="flex flex-wrap md:flex-nowrap md:space-x-12 max-md:space-y-5">
                          <div className="description-checkbox text-center flex md:flex-nowrap max-md:flex-col gap-x-6 2xl:gap-x-8">
                            {recipeFormConfig.description.map(
                              (option, index) => (
                                <label
                                  key={index}
                                  className="flex md:flex-col items-center gap-0"
                                >
                                  <Checkbox
                                    checked={
                                      formik.values.description?.[option.name]
                                        ? true
                                        : false
                                    }
                                    onChange={e =>
                                      formik.setFieldValue(
                                        `description.${option.name}`,
                                        e.target.checked,
                                      )
                                    }
                                  />
                                  {option.label}
                                </label>
                              ),
                            )}
                          </div>

                          <div className="description-delays flex flex-wrap md:flex-nowrap gap-x-6 2xl:gap-x-8 max-md:gap-y-2">
                            {recipeFormConfig.delays?.map((field, index) => (
                              <InputField
                                key={index}
                                formik={formik}
                                labelName={field.label}
                                field={`description.${field.name}`} // Set the field path to be within 'description'
                                type={field.type}
                                className={field.className}
                                disabled={field.disabled}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </form>
          </Box>
          {isModalOpen && (
            <PopupModal
              open={isModalOpen}
              onClose={handleCloseModal}
              currentJobType={formik.values.jobTypeId}
              defaultKpis={formik.values.kpis}
              refreshRecipes={getRecipes}
            />
          )}
          {isDeleteModalOpen && (
            <ConfirmationModal
              isOpen={isDeleteModalOpen}
              title="Confirm Deletion"
              description={`Are you sure you want to delete ${
                fieldOptions.recipeId.find(
                  option => option.value === formik.values.recipeId,
                )?.label
              }?`}
              onConfirm={removeRecipe}
              id={formik.values.recipeId}
              onCancel={cancelDelete}
              confirmText="Delete"
              cancelText="Cancel"
            />
          )}
        </>
      )}
    </>
  );
}

export default RecipeManagement;
