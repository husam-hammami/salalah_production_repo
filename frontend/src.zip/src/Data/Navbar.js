import {
  FaWarehouse,
  FaBarcode,
  FaBriefcase,
  FaMicrochip,
  FaUsers,
} from 'react-icons/fa';
import { FaGears } from 'react-icons/fa6';
import { Roles } from './Roles';

export const menuItems = [
  {
    name: 'Material',
    icon: FaWarehouse,
    tooltip: 'Material Management',
    link: '/materials',
    roles: [Roles.Admin, Roles.Manager, Roles.Operator],
  },
  {
    name: 'Bin',
    icon: FaBarcode,
    tooltip: 'Bin Assignment',
    link: '/bin',
    roles: [Roles.Admin, Roles.Manager, Roles.Operator],
  },
  {
    name: 'Job Type',
    icon: FaBriefcase,
    tooltip: 'Job Type Management',
    link: '/job-type',
    roles: [Roles.Admin],
  },
  {
    name: 'Recipe',
    icon: FaMicrochip,
    tooltip: 'Recipe Management',
    link: '/recipe',
    roles: [Roles.Admin, Roles.Manager, Roles.Operator],
  },
  {
    name: 'User',
    icon: FaUsers,
    tooltip: 'User Management',
    link: '/user',
    roles: [Roles.Admin, Roles.Manager],
  },
];

export const bluePrint = {
  name: 'Orders',
  icon: FaGears,
  tooltip: 'Orders Page',
  link: '/orders',
  roles: [Roles.Admin, Roles.Manager, Roles.Operator],
};
