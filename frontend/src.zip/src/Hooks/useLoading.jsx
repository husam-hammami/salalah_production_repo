import { useEffect, useState } from "react";

function useLoading() {
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setLoading(false);
  }, []);
  return loading;
}

export default useLoading;
