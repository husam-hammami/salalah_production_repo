import { useContext } from 'react';
import { BinsProvider } from '../Context/ApiContext/BinsContext';
import { JobTypesProvider } from '../Context/ApiContext/JobTypesContext';
import { MaterialsProvider } from '../Context/ApiContext/MaterialsContext';
import { OrdersProvider } from '../Context/ApiContext/OrdersContext';
import { UsersProvider } from '../Context/ApiContext/UsersContext';
import { DarkModeProvider } from '../Context/DarkModeProvider';
import { NavbarProvider } from '../Context/NavbarContext';
import { AuthContext } from '../Context/AuthProvider';
import LoadingScreen from '../Components/Common/LoadingScreen';

const AppProviders = ({ children }) => {
  const { authLoading } = useContext(AuthContext);

  if (authLoading) {
    return <LoadingScreen />;
  }

  return (
    <NavbarProvider>
      <DarkModeProvider>
        <MaterialsProvider>
          <BinsProvider>
            <JobTypesProvider>
              <OrdersProvider>
                <UsersProvider>{children}</UsersProvider>
              </OrdersProvider>
            </JobTypesProvider>
          </BinsProvider>
        </MaterialsProvider>
      </DarkModeProvider>
    </NavbarProvider>
  );
};

export default AppProviders;
