import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import Home from '../Pages/Home';
import Material from '../Pages/Material';
import Bin from '../Pages/Bin';
import JobType from '../Pages/JobType';
import Recipe from '../Pages/Recipe';
import User from '../Pages/User';
import Blueprint from '../Pages/Blueprint';
import Login from '../Pages/Login';
import { ProtectedCredentials, ProtectedRoute } from './ProtectedRoute';
import { Roles } from '../Data/Roles';

const AppRouter = () => {
  return (
    <BrowserRouter>
      <div className="mx-auto">
        <Routes>
          <Route
            path="/login"
            element={
              <ProtectedCredentials>
                <Login />
              </ProtectedCredentials>
            }
          />

          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Home />
              </ProtectedRoute>
            }
          >
            <Route
              index
              element={
                <ProtectedRoute>
                  <Navigate to="/materials" replace />
                </ProtectedRoute>
              }
            />
            <Route path="materials" element={<Material />} />
            <Route path="bin" element={<Bin />} />
            <Route
              path="job-type"
              element={
                <ProtectedRoute roles={[Roles.Admin]}>
                  <JobType />
                </ProtectedRoute>
              }
            />
            <Route path="recipe" element={<Recipe />} />
            <Route path="user" element={<ProtectedRoute roles={[Roles.Admin, Roles.Manager]}><User /></ProtectedRoute>} />
            <Route path="*" element={<Navigate to="/404" replace />} />
          </Route>
          <Route path="orders" element={<ProtectedRoute ><Blueprint /></ProtectedRoute>} />

          {/* <Route path='404' element={<NotFound />} /> */}
          <Route path="404" element={<div>Not found</div>} />
          <Route path="*" element={<Navigate to="/404" replace />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default AppRouter;
